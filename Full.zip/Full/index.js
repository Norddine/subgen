const express = require('express');
const fs = require('fs');
var Video_MP3 = require("./video_mp3");

var SpeechToTextV1 = require('watson-developer-cloud/speech-to-text/v1');

var speechToText = new SpeechToTextV1({
    iam_apikey: 'UVHHRXk5mAtu14UotZVcEEKxkkkOC0y1hd-g6cqojfLw',
    url: 'https://gateway-lon.watsonplatform.net/speech-to-text/api'
  });
var subs = "";
var index = 1;
var params = {
    "objectMode": true,
    "timestamps": true,
    "content-type": "audio/mp3",
    "model": "fr-FR_BroadbandModel",
    "keywords": [
     "durée du travail",
     "loisirs"
    ],
    "keywords_threshold": 0.01,
    "word_alternatives_threshold": 0.01,
    "smart_formatting": true,
    "speaker_labels": false,
    "max_alternatives": 0,
    "action": "start"
};

  // Create the stream.
  var recognizeStream = speechToText.recognizeUsingWebSocket(params);


const fileUpload = require('express-fileupload');
const app = express();

app.use(fileUpload());

// app.post('/link', upload.array(), function (req, res, next) {
//     console.log(req);
//   // req.body contains the text fields 
// });


app.get('/link', function (req, res) {
    let link = req.query.url;
    Video_MP3.convertYT(link, function(e) {
        if (e == "Finished") {
            analyseAudio(function(data) {
                if (data == "Saved!") {
                    console.log("Perfect");
                    res.send(subs);
                }
            });
        }
        

    });
    
    


})

app.get('/sub.srt', function (req, res) {
    res.download("./sub.srt");
})

app.post('/upload', function (req, res) {
    if (Object.keys(req.files).length == 0) {
        return res.status(400).send('No files were uploaded.');
    }
    let audio = req.files.audio;

    // Use the mv() method to place the file somewhere on your server
    audio.mv('./Video_MP3/audio.mp3', function(err) {
      if (err)
        return res.status(500).send(err);
  
      
      analyseAudio(function(data) {
          if (data == "Saved!") {
              console.log("Perfect");
              res.send(subs);
          }
      });

    });
});



var analyseAudio = function (callback) {
    console.log("Starting Analysing...")
    fs.createReadStream('./Video_MP3/audio.mp3').pipe(recognizeStream);
    recognizeStream.on('data', function(event) { onEvent('Data:', event); });
    recognizeStream.on('error', function(event) { onEventError('Error:', event); });
    //recognizeStream.on('close', function(event) { onEvent('Close:', event); });
    subs = "";
    index = 1;
    // Display events on the console.
    function onEvent(name, event) {
        event.results.map(function (obj,idx) {
            let transcript = obj.alternatives[0].transcript;
            let start = obj.alternatives[0].timestamps[0][1];
            let end = obj.alternatives[0].timestamps[obj.alternatives[0].timestamps.length-1][2];
            start = (start.toString()).replace(".", ",");
            start = "00:00:"+start;
            end = (end.toString()).replace(".", ",");
            end = "00:00:"+end+"0";
            subs = subs + index + "\n" + start + " --> " + end + "\n" + transcript + "\n\n";
            index++;


        });

        console.log(subs);
        fs.writeFile('sub.srt', "", (err) => {
            if (err) throw err;
            console.log("Creating a file...");
        }); 

        fs.appendFile('sub.srt', subs, function (err) {
            if (err) throw err;
            console.log('Saved!');
            callback("Saved!");
            //res file 
        });

    };

    function onEventError(name, event) {
        console.log(name, JSON.stringify(event, null, 2));

    };
}



app.listen(3000);