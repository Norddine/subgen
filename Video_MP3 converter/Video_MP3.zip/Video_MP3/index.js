var horizon = require('horizon-youtube-mp3');
var ffmpeg = require('fluent-ffmpeg');

convertYT = function (videoURL, callback) {

    var savedir = __dirname;

    horizon.getInfo(videoURL,function(err, data) {
        //var oldName=data.videoName;
        //console.log("Old Name: "+oldName);

        //var newName = oldName.replace(/[^\w\s]/gi, '')+".mp3";
        //console.log("New Name: "+ newName);

        var newName = "audio.mp3";
    
        horizon.downloadToLocal(videoURL, savedir, newName,null,null,null,null);

    });

}

convertVideo = function(videoPATH, callback) {
    
var savedir = __dirname;
var saveName = savedir+"/audio.mp3";

    ffmpeg(videoPATH)
        .toFormat('mp3')
        .on('end', function() {                    
            console.log('conversion ended');
            callback(null);
        }).on('error', function(err){
            console.log('error!!: ',err);
            callback(err);
        }).saveToFile(saveName);
}

module.exports = { 
    convertYT : convertYT,
    convertVideo : convertVideo
};