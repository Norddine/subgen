var ffmpeg = require('fluent-ffmpeg');

var fs = require('fs');
var youtubedl = require('youtube-dl');

convertYT = function (videoURL, callback) {
    var video = youtubedl(videoURL,
        // Optional arguments passed to youtube-dl.
        ['--format=18'],
        // Additional options can be given for calling `child_process.execFile()`.
        {
            cwd: __dirname
        });

    video.on('info', function (info) {
        console.log('Download started');
        console.log('filename: ' + info.filename);
        console.log('size: ' + info.size);
    });


    var output = "video.mp4";
    var path = __dirname + "/" + output;
    var result = video.pipe(fs.createWriteStream(path));
    result.on("finish", function() {
        console.log("Finished writing on pipe")
        convertVideo(path, function(status) {
            if (status=="Finished mp3")
                callback("Finished");
        });
    })
}

convertVideo = function (videoPATH, callback) {

    var savedir = __dirname;
    var saveName = savedir + "/audio.mp3";

    ffmpeg(videoPATH)
        .toFormat('mp3')
        .on('end', function () {
            console.log('conversion ended');
            callback("Finished mp3");
        }).on('error', function (err) {
            console.log('error!!: ', err);
            callback(err);
        }).saveToFile(saveName);
}

module.exports = {
    convertYT: convertYT,
    convertVideo: convertVideo
};